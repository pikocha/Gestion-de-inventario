DESCRIBE productos;
