SELECT * FROM productos;
INSERT INTO productos (nombre, descripcion, precio) VALUES ('iPhone 14', 'Smartphone de alta gama', 999.99);