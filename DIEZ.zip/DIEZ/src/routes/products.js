// src/routes/products.js
const express = require('express');
const router = express.Router();
const { getConnection } = require('../config/db');
const authenticateToken = require('../middleware/auth'); // Importar el middleware

// Proteger todas las rutas con autenticación
router.use(authenticateToken);

// Obtener todos los productos
router.get('/', async (req, res) => {
    try {
        const connection = await getConnection();
        const rows = await connection.query('SELECT * FROM productos');
        res.json(rows);
        connection.release(); // Liberar la conexión
    } catch (err) {
        console.error('Error al obtener productos:', err);
        res.status(500).json({ error: 'Error al obtener productos' });
    }
});

// Crear un nuevo producto
// Crear un nuevo producto
router.post('/', async (req, res) => {
    const { nombre, descripcion, cantidad, precio } = req.body;

    if (!nombre || !precio) {
        return res.status(400).json({ error: 'Nombre y precio son obligatorios' });
    }

    try {
        const connection = await getConnection();
        const result = await connection.query('INSERT INTO productos (nombre, descripcion, cantidad, precio) VALUES (?, ?, ?, ?)', 
            [nombre, descripcion, cantidad || 0, precio]);
        
        // Convertir el ID a string
        res.json({ 
            id: result.insertId.toString(), 
            nombre, 
            descripcion, 
            cantidad, 
            precio 
        });
        connection.release();
    } catch (err) {
        console.error('Error al crear producto:', err);
        res.status(500).json({ error: 'Error al crear producto' });
    }
});
// Actualizar un producto
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { nombre, descripcion, cantidad, precio } = req.body;

    try {
        const connection = await getConnection();
        const result = await connection.query('UPDATE productos SET nombre = ?, descripcion = ?, cantidad = ?, precio = ? WHERE id = ?', 
            [nombre, descripcion, cantidad, precio, id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }
        res.json({ id, nombre, descripcion, cantidad, precio });
        connection.release();
    } catch (err) {
        console.error('Error al actualizar producto:', err);
        res.status(500).json({ error: 'Error al actualizar producto' });
    }
});

// Eliminar un producto
router.delete('/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const connection = await getConnection();
        const result = await connection.query('DELETE FROM productos WHERE id = ?', [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }
        res.json({ message: 'Producto eliminado' });
        connection.release();
    } catch (err) {
        console.error('Error al eliminar producto:', err);
        res.status(500).json({ error: 'Error al eliminar producto' });
    }
});

module.exports = router;

