const mariadb = require('mariadb');

// Crear el pool de conexiones a MariaDB
const pool = mariadb.createPool({
    host: 'localhost', // Cambia si tienes otro host
    user: 'pikocha', // Cambia por tu usuario de MariaDB
    password: 'SaSoVo', // Cambia por tu contraseña de MariaDB
    database: 'inventario_db',
    connectionLimit: 5
});

// Función para obtener una conexión
async function getConnection() {
    try {
        const connection = await pool.getConnection();
        return connection;
    } catch (err) {
        console.error('Error al conectar con la base de datos:', err);
        throw err;
    }
}

module.exports = { getConnection };


