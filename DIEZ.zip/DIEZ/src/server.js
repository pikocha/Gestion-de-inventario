const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config(); // Cargar variables de entorno

const app = express();

// Importar las rutas
const productsRoutes = require('./routes/products');
const authRoutes = require('./routes/auth');

app.use(cors());
app.use(express.json());

// Rutas
app.get('/', (req, res) => {
    res.send('¡Bienvenido a la API!');
});

// Usar las rutas
app.use('/api/products', productsRoutes);
app.use('/api/auth', authRoutes); // Si tienes rutas de autenticación

// Manejo de errores
app.use((req, res) => {
    res.status(404).json({ error: 'Ruta no encontrada' });
});

// Puerto en el que escuchará
const PORT = process.env.PORT || 3002;

app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${PORT}`);
});
