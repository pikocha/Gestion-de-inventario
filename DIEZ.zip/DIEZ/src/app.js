// src/server.js
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

// Configurar dotenv para cargar variables de entorno
dotenv.config();

const app = express();

// Importar las rutas de productos y autenticación
const productsRoutes = require('./routes/products');
const authRoutes = require('./routes/auth'); // Rutas de autenticación

// Middlewares
app.use(cors());
app.use(express.json()); // Para parsear JSON

// Rutas
app.get('/', (req, res) => {
    res.send('¡Bienvenido a la API!');
});

// Rutas de productos
app.use('/api/products', productsRoutes);

// Rutas de autenticación
app.use('/api', authRoutes); // Agregar las rutas de autenticación

// Manejar errores no encontrados
app.use((req, res) => {
    res.status(404).json({ error: 'Ruta no encontrada' });
});

// Manejar errores internos del servidor
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Error interno del servidor' });
});

module.exports = app;

