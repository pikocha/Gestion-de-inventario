INSERT INTO productos (nombre, descripcion, cantidad, precio) VALUES
('Laptop', 'Laptop Dell Inspiron', 10, 1200.00),
('Monitor', 'Monitor 24 pulgadas Samsung', 20, 250.00),
('Teclado', 'Teclado mecánico RGB', 15, 80.00),
('Ratón', 'Ratón inalámbrico Logitech', 25, 50.00),
('Impresora', 'Impresora multifuncional HP', 5, 150.00);
